//
//  CustomCollectionViewFlowLayout.m
//  HelloWorld
//
//  Created by  huwenqiang on 2024/3/18.
//

#import "CustomCollectionViewFlowLayout.h"

@implementation CustomCollectionViewFlowLayout

- (instancetype)init {
    self = [super init];
    if (self) {
        self.minimumInteritemSpacing = 0; // 设置列间距为0
        self.minimumLineSpacing = 0; // 设置行间距为0
    }
    return self;
}

- (NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect {
    NSArray<UICollectionViewLayoutAttributes *> *attributes = [super layoutAttributesForElementsInRect:rect];

    for (UICollectionViewLayoutAttributes *attr in attributes) {
        if (attr.representedElementKind == UICollectionElementKindSectionHeader) {
            continue;
        }

        if (attr.indexPath.item % 2 == 1) {
            CGRect frame = attr.frame;
            frame.origin.x = self.collectionView.frame.size.width / 2;
            attr.frame = frame;
        }
    }

    return attributes;
}

@end
