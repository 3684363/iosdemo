//
//  AppDelegate.h
//  HelloWorld
//
//  Created by  huwenqiang on 2024/3/3.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

